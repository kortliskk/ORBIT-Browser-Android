package com.orbit.browser;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

final class BrowserDatabase extends SQLiteOpenHelper {
    private static final String DB_NAME = "orbit-browser.db";
    private static final int DB_VERSION = 1;

    BrowserDatabase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE history (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, url TEXT NOT NULL, visited_at INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX history_visited_idx ON history(visited_at DESC)");
        db.execSQL("CREATE TABLE bookmarks (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, url TEXT NOT NULL UNIQUE, created_at INTEGER NOT NULL)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Version 1 is the first released schema. Future migrations belong here.
    }

    synchronized void addHistory(String title, String url) {
        if (url == null || url.isEmpty()) return;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("title", title == null ? url : title);
        values.put("url", url);
        values.put("visited_at", System.currentTimeMillis());
        db.insert("history", null, values);
        db.execSQL("DELETE FROM history WHERE id NOT IN (SELECT id FROM history ORDER BY visited_at DESC LIMIT 700)");
    }

    synchronized boolean addBookmark(String title, String url) {
        if (url == null || url.isEmpty()) return false;
        ContentValues values = new ContentValues();
        values.put("title", title == null ? url : title);
        values.put("url", url);
        values.put("created_at", System.currentTimeMillis());
        long result = getWritableDatabase().insertWithOnConflict("bookmarks", null, values, SQLiteDatabase.CONFLICT_REPLACE);
        return result != -1;
    }

    synchronized List<Row> getHistory() { return getRows("history", "visited_at DESC"); }
    synchronized List<Row> getBookmarks() { return getRows("bookmarks", "created_at DESC"); }

    private List<Row> getRows(String table, String order) {
        List<Row> rows = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT id, title, url, " + (table.equals("history") ? "visited_at" : "created_at") + " FROM " + table + " ORDER BY " + order + " LIMIT 500", null)) {
            while (c.moveToNext()) rows.add(new Row(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3)));
        }
        return rows;
    }

    synchronized void removeBookmark(long id) { getWritableDatabase().delete("bookmarks", "id=?", new String[]{String.valueOf(id)}); }
    synchronized void removeHistory(long id) { getWritableDatabase().delete("history", "id=?", new String[]{String.valueOf(id)}); }
    synchronized void clearHistory() { getWritableDatabase().delete("history", null, null); }
    synchronized void clearBookmarks() { getWritableDatabase().delete("bookmarks", null, null); }

    static final class Row {
        final long id;
        final String title;
        final String url;
        final long timestamp;
        Row(long id, String title, String url, long timestamp) {
            this.id = id; this.title = title; this.url = url; this.timestamp = timestamp;
        }
        @Override public String toString() { return (title == null || title.trim().isEmpty() ? url : title) + "\n" + url; }
    }
}
