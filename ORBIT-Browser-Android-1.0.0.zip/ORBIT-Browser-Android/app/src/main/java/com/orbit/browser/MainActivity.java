package com.orbit.browser;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.SafeBrowsingResponse;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.File;
import java.io.FileWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;

public class MainActivity extends Activity {
    private static final String PREFS = "orbit_preferences";
    private static final String HOME_URL = "orbit://home";
    private static final String FILTER_URL = "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts";
    private static final int BG = Color.rgb(11, 16, 32);
    private static final int PANEL = Color.rgb(18, 26, 47);
    private static final int PANEL_2 = Color.rgb(25, 36, 61);
    private static final int TEXT = Color.rgb(236, 243, 255);
    private static final int MUTED = Color.rgb(150, 166, 190);
    private static final int ACCENT = Color.rgb(89, 226, 208);

    private final ArrayList<Tab> tabs = new ArrayList<>();
    private final Set<String> blockedHosts = ConcurrentHashMap.newKeySet();
    private final Set<String> exceptions = new CopyOnWriteArraySet<>();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private SharedPreferences prefs;
    private BrowserDatabase database;
    private DownloadManager downloadManager;
    private LinearLayout root;
    private LinearLayout tabStrip;
    private FrameLayout webContainer;
    private EditText addressInput;
    private TextView statusText;
    private int activeIndex = -1;
    private volatile String topLevelHost = "";
    private volatile boolean adBlockEnabled = true;
    private volatile String searchEngine = "Google";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(Color.rgb(8, 13, 25));
        getWindow().getDecorView().setSystemUiVisibility(0);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        database = new BrowserDatabase(this);
        downloadManager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        adBlockEnabled = prefs.getBoolean("adblock", true);
        searchEngine = prefs.getString("search_engine", "Google");
        Set<String> saved = prefs.getStringSet("exceptions", Collections.emptySet());
        if (saved != null) exceptions.addAll(saved);
        loadInitialFilterHosts();
        buildInterface();
        restoreSession();
        if (adBlockEnabled && prefs.getLong("filter_updated", 0L) == 0L) {
            statusText.setText("Reklam filtresi hazır · Liste güncellenebilir");
        }
    }

    private void buildInterface() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(10), dp(8), dp(10), dp(6));
        setContentView(root);

        LinearLayout brandRow = new LinearLayout(this);
        brandRow.setGravity(Gravity.CENTER_VERTICAL);
        brandRow.setPadding(dp(3), dp(2), dp(3), dp(7));
        ImageView logo = new ImageView(this);
        logo.setImageResource(com.orbit.browser.R.drawable.orbit_logo);
        brandRow.addView(logo, new LinearLayout.LayoutParams(dp(31), dp(31)));
        TextView brand = new TextView(this);
        brand.setText("ORBIT");
        brand.setTextColor(TEXT);
        brand.setTextSize(18);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        brand.setLetterSpacing(0.12f);
        LinearLayout.LayoutParams brandLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        brandLp.leftMargin = dp(8);
        brandRow.addView(brand, brandLp);
        TextView historyQuick = makeButton("◷", PANEL, TEXT);
        historyQuick.setContentDescription("Geçmiş");
        historyQuick.setOnClickListener(v -> showRowsDialog("Geçmiş", database.getHistory(), false));
        brandRow.addView(historyQuick, new LinearLayout.LayoutParams(dp(42), dp(38)));
        TextView settingsQuick = makeButton("⚙", PANEL, TEXT);
        settingsQuick.setContentDescription("Ayarlar");
        settingsQuick.setOnClickListener(v -> showSettings());
        LinearLayout.LayoutParams settingsLp = new LinearLayout.LayoutParams(dp(42), dp(38));
        settingsLp.leftMargin = dp(6);
        brandRow.addView(settingsQuick, settingsLp);
        root.addView(brandRow);

        LinearLayout addressRow = new LinearLayout(this);
        addressRow.setGravity(Gravity.CENTER_VERTICAL);
        addressRow.setPadding(dp(9), 0, dp(5), 0);
        addressRow.setBackground(round(PANEL_2, 15, Color.rgb(48, 65, 96), 1));
        addressInput = new EditText(this);
        addressInput.setSingleLine(true);
        addressInput.setTextColor(TEXT);
        addressInput.setHintTextColor(MUTED);
        addressInput.setHint("Ara veya web adresi gir");
        addressInput.setTextSize(15);
        addressInput.setSelectAllOnFocus(true);
        addressInput.setImeOptions(EditorInfo.IME_ACTION_GO);
        addressInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
        addressInput.setBackgroundColor(Color.TRANSPARENT);
        addressRow.addView(addressInput, new LinearLayout.LayoutParams(0, dp(48), 1f));
        TextView go = makeButton("Git  ↗", ACCENT, Color.rgb(8, 25, 34));
        go.setTextSize(13);
        go.setOnClickListener(v -> submitAddress());
        addressRow.addView(go, new LinearLayout.LayoutParams(dp(68), dp(38)));
        addressInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                submitAddress(); return true;
            }
            return false;
        });
        root.addView(addressRow);

        HorizontalScrollView tabScroller = new HorizontalScrollView(this);
        tabScroller.setHorizontalScrollBarEnabled(false);
        tabScroller.setFillViewport(false);
        tabStrip = new LinearLayout(this);
        tabStrip.setGravity(Gravity.CENTER_VERTICAL);
        tabStrip.setPadding(0, dp(7), 0, dp(7));
        tabScroller.addView(tabStrip, new HorizontalScrollView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)));
        root.addView(tabScroller);

        webContainer = new FrameLayout(this);
        webContainer.setBackground(round(Color.rgb(14, 21, 38), 12, Color.rgb(35, 50, 76), 1));
        root.addView(webContainer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        statusText = new TextView(this);
        statusText.setText("Güvenli gezinme · Chromium WebView");
        statusText.setTextSize(11);
        statusText.setTextColor(MUTED);
        statusText.setGravity(Gravity.CENTER_VERTICAL);
        statusText.setPadding(dp(5), dp(5), dp(5), dp(2));
        root.addView(statusText, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));

        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(0, dp(3), 0, 0);
        addNavButton(nav, "‹", "Geri", this::goBack);
        addNavButton(nav, "›", "İleri", this::goForward);
        addNavButton(nav, "⌂", "Ana sayfa", this::goHome);
        addNavButton(nav, "↻", "Yenile", this::reload);
        addNavButton(nav, "☆", "Yer imi ekle", this::addBookmark);
        addNavButton(nav, "↓", "İndirilenler", this::showDownloads);
        root.addView(nav);

        LinearLayout quick = new LinearLayout(this);
        quick.setGravity(Gravity.CENTER);
        quick.setPadding(0, dp(5), 0, 0);
        addQuickButton(quick, "Yer İmleri", () -> showRowsDialog("Yer İmleri", database.getBookmarks(), true));
        addQuickButton(quick, "Geçmiş", () -> showRowsDialog("Geçmiş", database.getHistory(), false));
        addQuickButton(quick, "Uzantılar", this::showExtensionNotice);
        addQuickButton(quick, "Ayarlar", this::showSettings);
        root.addView(quick);
    }

    private void addNavButton(LinearLayout row, String glyph, String label, Runnable action) {
        TextView b = makeButton(glyph, PANEL, TEXT);
        b.setTextSize(22);
        b.setContentDescription(label);
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(43), 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        row.addView(b, lp);
    }

    private void addQuickButton(LinearLayout row, String label, Runnable action) {
        TextView b = makeButton(label, Color.TRANSPARENT, MUTED);
        b.setTextSize(11);
        b.setOnClickListener(v -> action.run());
        row.addView(b, new LinearLayout.LayoutParams(0, dp(32), 1f));
    }

    private TextView makeButton(String text, int background, int foreground) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(foreground);
        v.setTextSize(15);
        v.setGravity(Gravity.CENTER);
        v.setIncludeFontPadding(false);
        v.setBackground(round(background, 12, background == Color.TRANSPARENT ? Color.TRANSPARENT : background, 0));
        v.setClickable(true);
        v.setFocusable(true);
        return v;
    }

    private GradientDrawable round(int color, int radiusDp, int stroke, int strokeWidthDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeWidthDp > 0) d.setStroke(dp(strokeWidthDp), stroke);
        return d;
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private void restoreSession() {
        String raw = prefs.getString("session", "");
        boolean restored = false;
        if (!raw.isEmpty()) {
            try {
                JSONObject session = new JSONObject(raw);
                JSONArray urls = session.optJSONArray("tabs");
                if (urls != null) {
                    for (int i = 0; i < urls.length() && i < 8; i++) {
                        String url = urls.optString(i, HOME_URL);
                        addTab(url, false);
                    }
                    int selected = session.optInt("active", 0);
                    if (!tabs.isEmpty()) selectTab(Math.max(0, Math.min(selected, tabs.size() - 1)));
                    restored = !tabs.isEmpty();
                }
            } catch (Exception ignored) { }
        }
        if (!restored) addTab(HOME_URL, true);
    }

    private void saveSession() {
        try {
            JSONArray urls = new JSONArray();
            for (Tab tab : tabs) urls.put(tab.url == null ? HOME_URL : tab.url);
            JSONObject obj = new JSONObject();
            obj.put("tabs", urls);
            obj.put("active", Math.max(0, activeIndex));
            prefs.edit().putString("session", obj.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void addTab(String initialUrl, boolean focus) {
        if (tabs.size() >= 8) {
            Toast.makeText(this, "En fazla 8 sekme açılabilir.", Toast.LENGTH_SHORT).show();
            if (focus) selectTab(activeIndex);
            return;
        }
        WebView web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSafeBrowsingEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        if (android.os.Build.VERSION.SDK_INT >= 33) settings.setAlgorithmicDarkeningAllowed(false);

        Tab tab = new Tab(web);
        tabs.add(tab);
        FrameLayout.LayoutParams webLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        webContainer.addView(web, webLp);
        web.setVisibility(View.GONE);

        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onReceivedTitle(WebView view, String title) {
                tab.title = title == null || title.trim().isEmpty() ? "Yeni Sekme" : title;
                if (tabs.contains(tab)) renderTabs();
            }
            @Override public void onProgressChanged(WebView view, int progress) {
                if (tabs.indexOf(tab) == activeIndex) {
                    statusText.setText(progress < 100 ? "Sayfa yükleniyor · " + progress + "%" : "Güvenli gezinme · " + hostLabel(tab.url));
                }
            }
        });

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
                if (scheme.equals("http") || scheme.equals("https")) return false;
                if (scheme.equals("mailto") || scheme.equals("tel")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
                    return true;
                }
                return true;
            }

            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                tab.url = normalizeLoadedUrl(url);
                topLevelHost = hostOf(url);
                if (tabs.indexOf(tab) == activeIndex) updateAddressFromTab(tab);
            }

            @Override public void onPageFinished(WebView view, String url) {
                tab.url = normalizeLoadedUrl(url);
                if (!isHomePage(url) && url.startsWith("https://") || (!isHomePage(url) && url.startsWith("http://"))) {
                    database.addHistory(tab.title, url);
                }
                if (tabs.indexOf(tab) == activeIndex) {
                    updateAddressFromTab(tab);
                    statusText.setText("Güvenli gezinme · " + hostLabel(url));
                }
                renderTabs();
            }

            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                Toast.makeText(MainActivity.this, "Güvenli bağlantı doğrulanamadı. Sayfa açılmadı.", Toast.LENGTH_LONG).show();
            }

            @Override public void onSafeBrowsingHit(WebView view, WebResourceRequest request, int threatType, SafeBrowsingResponse callback) {
                if (android.os.Build.VERSION.SDK_INT >= 27) callback.backToSafety(true);
                else super.onSafeBrowsingHit(view, request, threatType, callback);
            }

            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (!adBlockEnabled) return null;
                String resourceHost = request.getUrl().getHost();
                if (resourceHost == null || resourceHost.isEmpty()) return null;
                String pageHost = hostOf(tab.url);
                if (isExceptionPage(pageHost)) return null;
                if (isBlockedHost(resourceHost)) {
                    return new WebResourceResponse("text/plain", "UTF-8", 204, "Blocked by ORBIT", Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
                }
                return null;
            }
        });

        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> enqueueDownload(url, userAgent, contentDisposition, mimeType));
        if (focus) selectTab(tabs.size() - 1);
        else { web.onPause(); renderTabs(); }
        if (initialUrl == null || initialUrl.isEmpty() || HOME_URL.equals(initialUrl)) loadHome(tab);
        else web.loadUrl(initialUrl);
    }

    private void loadHome(Tab tab) {
        tab.url = HOME_URL;
        tab.title = "Yeni Sekme";
        topLevelHost = "";
        tab.webView.loadDataWithBaseURL("https://orbit.start/", HOME_HTML, "text/html", "UTF-8", null);
        if (tabs.indexOf(tab) == activeIndex) updateAddressFromTab(tab);
    }

    private static final String HOME_HTML = "<!doctype html><html lang='tr'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><style>" +
            "*{box-sizing:border-box}body{margin:0;min-height:100vh;background:radial-gradient(ellipse at 20% 0%,#17284a 0,#0e172b 45%,#0b1020 100%);font-family:Arial,sans-serif;color:#edf5ff;display:flex;align-items:center;justify-content:center;padding:26px}" +
            ".wrap{max-width:740px;width:100%;text-align:center}.orb{font-size:52px;color:#59e2d0;text-shadow:0 0 35px #59e2d077}.eyebrow{color:#59e2d0;font-size:12px;letter-spacing:4px;font-weight:bold;margin-top:14px}h1{font-size:34px;margin:9px 0 8px}p{color:#9aadc9;line-height:1.6}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(135px,1fr));gap:12px;margin-top:30px}.card{display:block;text-decoration:none;color:#eef7ff;background:#172440;border:1px solid #2b4164;border-radius:17px;padding:20px 12px;font-weight:bold}.card span{display:block;font-size:25px;margin-bottom:9px;color:#59e2d0}.hint{font-size:12px;margin-top:28px;color:#7f91ad}</style></head><body><main class='wrap'><div class='orb'>◉</div><div class='eyebrow'>ORBIT BROWSER</div><h1>Keşfetmeye başla.</h1><p>Adres çubuğuna bir web adresi ya da arama kelimesi yaz.<br>Hızlı erişim için bir site seç.</p><section class='grid'><a class='card' href='https://www.google.com'><span>G</span>Google</a><a class='card' href='https://www.youtube.com'><span>▶</span>YouTube</a><a class='card' href='https://www.wikipedia.org'><span>W</span>Wikipedia</a><a class='card' href='https://duckduckgo.com'><span>⌕</span>DuckDuckGo</a></section><div class='hint'>Gizlilik odaklı · Sekmeli gezinme · Reklam filtresi</div></main></body></html>";

    private void selectTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        if (activeIndex >= 0 && activeIndex < tabs.size() && activeIndex != index) tabs.get(activeIndex).webView.onPause();
        activeIndex = index;
        for (int i = 0; i < tabs.size(); i++) tabs.get(i).webView.setVisibility(i == index ? View.VISIBLE : View.GONE);
        Tab active = tabs.get(index);
        active.webView.onResume();
        topLevelHost = hostOf(active.url);
        updateAddressFromTab(active);
        renderTabs();
        saveSession();
    }

    private void renderTabs() {
        if (tabStrip == null) return;
        tabStrip.removeAllViews();
        for (int i = 0; i < tabs.size(); i++) {
            final int index = i;
            Tab tab = tabs.get(i);
            LinearLayout chip = new LinearLayout(this);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            chip.setPadding(dp(10), 0, dp(6), 0);
            chip.setBackground(round(i == activeIndex ? Color.rgb(31, 69, 78) : PANEL, 12, i == activeIndex ? ACCENT : Color.rgb(45, 59, 84), 1));
            TextView title = new TextView(this);
            title.setText(tab.title == null ? "Yeni Sekme" : tab.title);
            title.setTextColor(i == activeIndex ? ACCENT : TEXT);
            title.setTextSize(12);
            title.setMaxLines(1);
            title.setMaxWidth(dp(118));
            title.setEllipsize(android.text.TextUtils.TruncateAt.END);
            chip.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)));
            TextView close = new TextView(this);
            close.setText("×");
            close.setTextColor(MUTED);
            close.setTextSize(18);
            close.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(dp(25), dp(34));
            closeLp.leftMargin = dp(4);
            chip.addView(close, closeLp);
            title.setOnClickListener(v -> selectTab(index));
            close.setOnClickListener(v -> closeTab(index));
            chip.setOnClickListener(v -> selectTab(index));
            LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36));
            chipLp.setMargins(0, 0, dp(7), 0);
            tabStrip.addView(chip, chipLp);
        }
        TextView add = makeButton("＋", ACCENT, Color.rgb(8, 25, 34));
        add.setTextSize(21);
        add.setOnClickListener(v -> addTab(HOME_URL, true));
        LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(dp(39), dp(36));
        tabStrip.addView(add, addLp);
    }

    private void closeTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        Tab tab = tabs.remove(index);
        tab.webView.stopLoading();
        webContainer.removeView(tab.webView);
        tab.webView.destroy();
        if (tabs.isEmpty()) {
            activeIndex = -1;
            addTab(HOME_URL, true);
        } else {
            int next = activeIndex;
            if (index < activeIndex) next--;
            else if (index == activeIndex) next = Math.min(index, tabs.size() - 1);
            selectTab(Math.max(0, next));
        }
        renderTabs();
        saveSession();
    }

    private void submitAddress() {
        String raw = addressInput.getText().toString().trim();
        if (raw.isEmpty()) return;
        String target = resolveInput(raw);
        hideKeyboard();
        addressInput.clearFocus();
        if (activeIndex < 0) addTab(HOME_URL, true);
        Tab tab = tabs.get(activeIndex);
        tab.url = target;
        tab.webView.loadUrl(target);
        saveSession();
    }

    private String resolveInput(String raw) {
        String lower = raw.toLowerCase(Locale.ROOT);
        if (lower.startsWith("https://") || lower.startsWith("http://")) return raw;
        if (!raw.contains(" ") && (raw.equals("localhost") || raw.matches("(?i)^[a-z0-9.-]+\\.[a-z]{2,}(:[0-9]+)?(/.*)?$"))) return "https://" + raw;
        String base = searchEngine.equals("Bing") ? "https://www.bing.com/search?q=" : searchEngine.equals("DuckDuckGo") ? "https://duckduckgo.com/?q=" : "https://www.google.com/search?q=";
        try { return base + URLEncoder.encode(raw, "UTF-8"); } catch (Exception e) { return base + Uri.encode(raw); }
    }

    private void updateAddressFromTab(Tab tab) {
        if (addressInput == null) return;
        String url = tab.url;
        addressInput.setText(url == null || HOME_URL.equals(url) ? "" : url);
    }

    private String normalizeLoadedUrl(String url) { return isHomePage(url) ? HOME_URL : url; }
    private boolean isHomePage(String url) { return url != null && (url.startsWith("https://orbit.start/") || url.equals(HOME_URL)); }

    private void goBack() { if (activeTab() != null && activeTab().webView.canGoBack()) activeTab().webView.goBack(); }
    private void goForward() { if (activeTab() != null && activeTab().webView.canGoForward()) activeTab().webView.goForward(); }
    private void reload() { if (activeTab() != null) activeTab().webView.reload(); }
    private void goHome() { if (activeTab() != null) loadHome(activeTab()); }
    private Tab activeTab() { return activeIndex >= 0 && activeIndex < tabs.size() ? tabs.get(activeIndex) : null; }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(addressInput.getWindowToken(), 0);
        } catch (Exception ignored) { }
    }

    private void enqueueDownload(String url, String userAgent, String disposition, String mimeType) {
        try {
            Uri uri = Uri.parse(url);
            DownloadManager.Request request = new DownloadManager.Request(uri);
            String fileName = android.webkit.URLUtil.guessFileName(url, disposition, mimeType);
            request.setTitle(fileName);
            request.setDescription("ORBIT Browser indirme işlemi");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(false);
            if (userAgent != null) request.addRequestHeader("User-Agent", userAgent);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) request.addRequestHeader("Cookie", cookie);
            try {
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
            } catch (Exception ignored) {
                request.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, fileName);
            }
            long id = downloadManager.enqueue(request);
            Toast.makeText(this, "İndirme başladı: " + fileName, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "İndirme başlatılamadı: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void showDownloads() {
        DownloadManager.Query query = new DownloadManager.Query();
        Cursor cursor = downloadManager.query(query);
        ArrayList<Long> ids = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();
        if (cursor != null) {
            try {
                int idCol = cursor.getColumnIndex(DownloadManager.COLUMN_ID);
                int titleCol = cursor.getColumnIndex(DownloadManager.COLUMN_TITLE);
                int statusCol = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS);
                while (cursor.moveToNext()) {
                    long id = cursor.getLong(idCol);
                    int status = cursor.getInt(statusCol);
                    String state = status == DownloadManager.STATUS_SUCCESSFUL ? "Tamamlandı" : status == DownloadManager.STATUS_FAILED ? "Başarısız" : status == DownloadManager.STATUS_PAUSED ? "Duraklatıldı" : "İndiriliyor";
                    ids.add(id);
                    labels.add(cursor.getString(titleCol) + " · " + state);
                }
            } finally { cursor.close(); }
        }
        if (labels.isEmpty()) labels.add("Henüz indirme yok.");
        final ArrayList<String> finalLabels = labels;
        new AlertDialog.Builder(this).setTitle("İndirilenler")
                .setItems(finalLabels.toArray(new String[0]), (dialog, which) -> {
                    if (which >= ids.size()) return;
                    long id = ids.get(which);
                    try {
                        Uri file = downloadManager.getUriForDownloadedFile(id);
                        if (file == null) { Toast.makeText(this, "Dosya henüz hazır değil.", Toast.LENGTH_SHORT).show(); return; }
                        String type = getContentResolver().getType(file);
                        Intent open = new Intent(Intent.ACTION_VIEW).setDataAndType(file, type == null ? "*/*" : type).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(open);
                    } catch (Exception e) { Toast.makeText(this, "Dosyayı açacak uygulama bulunamadı.", Toast.LENGTH_SHORT).show(); }
                }).setPositiveButton("Kapat", null).show();
    }

    private void showRowsDialog(String title, List<BrowserDatabase.Row> rows, boolean bookmarks) {
        if (rows.isEmpty()) {
            new AlertDialog.Builder(this).setTitle(title).setMessage(bookmarks ? "Henüz yer imi eklenmedi." : "Gezinme geçmişi boş.").setPositiveButton("Tamam", null).show();
            return;
        }
        ListView list = new ListView(this);
        ArrayAdapter<BrowserDatabase.Row> adapter = new ArrayAdapter<BrowserDatabase.Row>(this, android.R.layout.simple_list_item_2, android.R.id.text1, rows) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView first = view.findViewById(android.R.id.text1);
                TextView second = view.findViewById(android.R.id.text2);
                BrowserDatabase.Row row = getItem(position);
                first.setText(row.title == null ? row.url : row.title);
                first.setTextColor(TEXT);
                second.setText(row.url);
                second.setTextColor(MUTED);
                view.setBackgroundColor(PANEL);
                return view;
            }
        };
        list.setAdapter(adapter);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(title).setView(list)
                .setNeutralButton(bookmarks ? "Tümünü sil" : "Geçmişi temizle", (d, w) -> {
                    if (bookmarks) database.clearBookmarks(); else database.clearHistory();
                    Toast.makeText(this, "Kayıtlar temizlendi.", Toast.LENGTH_SHORT).show();
                }).setNegativeButton("Kapat", null).create();
        list.setOnItemClickListener((parent, view, position, id) -> {
            BrowserDatabase.Row row = rows.get(position);
            if (activeTab() == null) addTab(HOME_URL, true);
            activeTab().webView.loadUrl(row.url);
            dialog.dismiss();
        });
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            BrowserDatabase.Row row = rows.get(position);
            new AlertDialog.Builder(this).setMessage(bookmarks ? "Bu yer imi silinsin mi?" : "Bu geçmiş kaydı silinsin mi?")
                    .setNegativeButton("İptal", null).setPositiveButton("Sil", (d, w) -> {
                        if (bookmarks) database.removeBookmark(row.id); else database.removeHistory(row.id);
                        rows.remove(row); adapter.notifyDataSetChanged();
                        if (rows.isEmpty()) dialog.dismiss();
                    }).show();
            return true;
        });
        dialog.show();
    }

    private void addBookmark() {
        Tab tab = activeTab();
        if (tab == null || tab.url == null || HOME_URL.equals(tab.url)) {
            Toast.makeText(this, "Önce bir web sayfası aç.", Toast.LENGTH_SHORT).show(); return;
        }
        boolean ok = database.addBookmark(tab.title, tab.url);
        Toast.makeText(this, ok ? "Yer imi kaydedildi." : "Yer imi kaydedilemedi.", Toast.LENGTH_SHORT).show();
    }

    private void showSettings() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18), dp(8), dp(18), dp(8));
        Switch adSwitch = new Switch(this);
        adSwitch.setText("Reklam ve izleyici engelleme");
        adSwitch.setTextColor(TEXT);
        adSwitch.setChecked(adBlockEnabled);
        form.addView(adSwitch, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        TextView filterInfo = new TextView(this);
        filterInfo.setText("Filtre: alan adı / hosts listesi. Gelişmiş kozmetik EasyList kuralları desteklenmez.");
        filterInfo.setTextColor(MUTED);
        filterInfo.setTextSize(12);
        form.addView(filterInfo);
        Button updateFilters = new Button(this);
        updateFilters.setText("Reklam listesini güncelle");
        form.addView(updateFilters);
        TextView exceptionLabel = new TextView(this);
        exceptionLabel.setText("Site istisnası (ör. example.com)");
        exceptionLabel.setTextColor(TEXT);
        exceptionLabel.setPadding(0, dp(12), 0, dp(4));
        form.addView(exceptionLabel);
        EditText exceptionInput = new EditText(this);
        exceptionInput.setSingleLine(true);
        exceptionInput.setHint("example.com");
        exceptionInput.setTextColor(TEXT);
        exceptionInput.setHintTextColor(MUTED);
        exceptionInput.setBackground(round(PANEL_2, 10, Color.rgb(52, 69, 96), 1));
        exceptionInput.setPadding(dp(10), 0, dp(10), 0);
        form.addView(exceptionInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));
        Button addException = new Button(this);
        addException.setText("İstisna ekle");
        form.addView(addException);
        TextView exceptionsText = new TextView(this);
        exceptionsText.setTextColor(MUTED);
        exceptionsText.setTextSize(12);
        exceptionsText.setPadding(0, dp(5), 0, dp(5));
        exceptionsText.setText(exceptions.isEmpty() ? "İstisna yok." : "İstisnalar: " + android.text.TextUtils.join(", ", exceptions));
        form.addView(exceptionsText);
        TextView engineLabel = new TextView(this);
        engineLabel.setText("Varsayılan arama motoru");
        engineLabel.setTextColor(TEXT);
        engineLabel.setPadding(0, dp(12), 0, dp(3));
        form.addView(engineLabel);
        Spinner engine = new Spinner(this);
        String[] engines = {"Google", "Bing", "DuckDuckGo"};
        engine.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, engines));
        engine.setSelection(Arrays.asList(engines).indexOf(searchEngine));
        form.addView(engine);
        Button clearHistory = new Button(this);
        clearHistory.setText("Gezinme geçmişini temizle");
        form.addView(clearHistory);
        TextView privacy = new TextView(this);
        privacy.setText("HTTPS sertifika hatalarında bağlantı reddedilir. Android System WebView, Chrome masaüstü uzantılarını çalıştırmaz.");
        privacy.setTextColor(MUTED);
        privacy.setTextSize(12);
        privacy.setPadding(0, dp(10), 0, 0);
        form.addView(privacy);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(form);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("ORBIT Ayarları").setView(scroll).setPositiveButton("Bitti", null).create();

        adSwitch.setOnCheckedChangeListener((button, checked) -> {
            adBlockEnabled = checked;
            prefs.edit().putBoolean("adblock", checked).apply();
            Toast.makeText(this, checked ? "Reklam filtresi açık." : "Reklam filtresi kapalı.", Toast.LENGTH_SHORT).show();
        });
        updateFilters.setOnClickListener(v -> {
            filterInfo.setText("Filtre listesi indiriliyor…");
            updateFilters.setEnabled(false);
            updateFilterList(success -> mainHandler.post(() -> {
                updateFilters.setEnabled(true);
                filterInfo.setText(success ? "Filtre listesi güncellendi · " + blockedHosts.size() + " alan adı" : "Güncelleme başarısız. İnternet bağlantısını kontrol et.");
            }));
        });
        addException.setOnClickListener(v -> {
            String domain = normalizeHost(exceptionInput.getText().toString());
            if (domain.isEmpty()) return;
            exceptions.add(domain);
            prefs.edit().putStringSet("exceptions", new java.util.HashSet<>(exceptions)).apply();
            exceptionsText.setText("İstisnalar: " + android.text.TextUtils.join(", ", exceptions));
            exceptionInput.setText("");
            Toast.makeText(this, domain + " için filtre atlandı.", Toast.LENGTH_SHORT).show();
        });
        engine.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                searchEngine = engines[position]; prefs.edit().putString("search_engine", searchEngine).apply();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });
        clearHistory.setOnClickListener(v -> new AlertDialog.Builder(this).setMessage("Tüm gezinme geçmişi silinsin mi?").setNegativeButton("İptal", null).setPositiveButton("Sil", (d, w) -> { database.clearHistory(); Toast.makeText(this, "Geçmiş temizlendi.", Toast.LENGTH_SHORT).show(); }).show());
        dialog.show();
    }

    private void showExtensionNotice() {
        new AlertDialog.Builder(this).setTitle("Uzantı desteği")
                .setMessage("Bu Android sürümü Android System WebView kullanır. WebView, Chrome masaüstü uzantı API'lerini desteklemez. Bu nedenle ORBIT Android sürümünde uzantı yükleme, etkinleştirme veya kaldırma özelliği sunulmuyor.")
                .setPositiveButton("Anladım", null).show();
    }

    private void loadInitialFilterHosts() {
        blockedHosts.addAll(Arrays.asList("doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com", "adnxs.com", "adsrvr.org", "taboola.com", "outbrain.com", "criteo.com", "scorecardresearch.com", "demdex.net", "hotjar.com", "zedo.com", "adform.net", "rubiconproject.com"));
        File filterFile = new File(getFilesDir(), "orbit-hosts.txt");
        if (filterFile.isFile()) {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(new java.io.FileInputStream(filterFile)))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String host = normalizeHost(line);
                    if (isValidDomain(host)) blockedHosts.add(host);
                }
            } catch (Exception ignored) { }
        }
    }

    private interface FilterCallback { void done(boolean success); }

    private void updateFilterList(FilterCallback callback) {
        new Thread(() -> {
            boolean success = false;
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(FILTER_URL).openConnection();
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(20000);
                connection.setRequestProperty("User-Agent", "ORBIT-Browser-Android/1.0");
                connection.connect();
                if (connection.getResponseCode() == 200) {
                    Set<String> fresh = ConcurrentHashMap.newKeySet();
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            line = line.trim();
                            if (line.isEmpty() || line.startsWith("#")) continue;
                            String[] parts = line.split("\\s+");
                            if (parts.length >= 2 && (parts[0].equals("0.0.0.0") || parts[0].equals("127.0.0.1") || parts[0].equals("::1"))) {
                                for (int i = 1; i < parts.length; i++) {
                                    String host = normalizeHost(parts[i]);
                                    if (isValidDomain(host) && !host.equals("localhost")) fresh.add(host);
                                }
                            }
                        }
                    }
                    if (!fresh.isEmpty()) {
                        File filterFile = new File(getFilesDir(), "orbit-hosts.txt");
                        try (FileWriter writer = new FileWriter(filterFile, false)) {
                            for (String host : fresh) writer.write(host + "\n");
                        }
                        blockedHosts.clear();
                        blockedHosts.addAll(fresh);
                        prefs.edit().putLong("filter_updated", System.currentTimeMillis()).apply();
                        success = true;
                    }
                }
            } catch (Exception ignored) {
            } finally { if (connection != null) connection.disconnect(); }
            if (callback != null) callback.done(success);
        }, "orbit-filter-update").start();
    }

    private boolean isBlockedHost(String host) {
        String normalized = normalizeHost(host);
        if (normalized.isEmpty()) return false;
        String candidate = normalized;
        while (!candidate.isEmpty()) {
            if (blockedHosts.contains(candidate)) return true;
            int dot = candidate.indexOf('.');
            if (dot < 0 || dot == candidate.length() - 1) break;
            candidate = candidate.substring(dot + 1);
        }
        return false;
    }

    private boolean isExceptionPage(String host) {
        String normalized = normalizeHost(host);
        if (normalized.isEmpty()) return false;
        for (String exception : exceptions) {
            if (normalized.equals(exception) || normalized.endsWith("." + exception)) return true;
        }
        return false;
    }

    private static String hostOf(String url) {
        try { String h = Uri.parse(url == null ? "" : url).getHost(); return h == null ? "" : h.toLowerCase(Locale.ROOT); }
        catch (Exception e) { return ""; }
    }

    private static String hostLabel(String url) {
        String host = hostOf(url);
        return host.isEmpty() ? "ORBIT hazır" : host;
    }

    private static String normalizeHost(String value) {
        if (value == null) return "";
        String v = value.trim().toLowerCase(Locale.ROOT);
        if (v.startsWith("http://") || v.startsWith("https://")) v = hostOf(v);
        if (v.startsWith("www.")) v = v.substring(4);
        int slash = v.indexOf('/'); if (slash >= 0) v = v.substring(0, slash);
        int colon = v.indexOf(':'); if (colon >= 0) v = v.substring(0, colon);
        return v.replaceAll("[^a-z0-9.-]", "");
    }

    private static boolean isValidDomain(String host) {
        return host != null && host.length() <= 253 && host.contains(".") && !host.startsWith(".") && !host.endsWith(".") && !host.contains("..");
    }

    @Override public void onBackPressed() {
        Tab tab = activeTab();
        if (tab != null && tab.webView.canGoBack()) tab.webView.goBack();
        else new AlertDialog.Builder(this).setMessage("ORBIT kapatılsın mı?").setNegativeButton("İptal", null).setPositiveButton("Kapat", (d, w) -> finish()).show();
    }

    @Override protected void onPause() {
        saveSession();
        for (Tab tab : tabs) tab.webView.onPause();
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        Tab tab = activeTab();
        if (tab != null) tab.webView.onResume();
    }

    @Override protected void onDestroy() {
        saveSession();
        for (Tab tab : new ArrayList<>(tabs)) {
            try { tab.webView.stopLoading(); tab.webView.destroy(); } catch (Exception ignored) { }
        }
        tabs.clear();
        if (database != null) database.close();
        super.onDestroy();
    }

    private static final class Tab {
        final WebView webView;
        String title = "Yeni Sekme";
        String url = HOME_URL;
        Tab(WebView webView) { this.webView = webView; }
    }
}
