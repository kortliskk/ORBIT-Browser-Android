# ORBIT Browser for Android

ORBIT Browser is an Android 10+ browser app built with Java and Android System WebView (the Chromium-based WebView installed and updated by Android). This project is separate from the Electron desktop edition; Electron itself is not used on Android.

## Included

- Real websites in Android WebView (Google, YouTube and other HTTP/HTTPS sites)
- Up to 8 WebView tabs, tab switching and closing
- Address bar with Google, Bing or DuckDuckGo search
- Back, forward, home and reload controls
- SQLite-backed bookmarks and browsing history
- Android DownloadManager integration and download notifications
- Preferences saved locally (search engine, ad-block toggle, site exceptions, session)
- Host-based ad/tracker blocking through `shouldInterceptRequest`
- Optional StevenBlack hosts-list update, stored as a file in app-private storage
- WebView Safe Browsing, HTTPS certificate error rejection, no mixed content, no file URL access

## Important limits

- **Extensions:** Android System WebView does not implement the Chrome desktop extensions API. ORBIT does not pretend to install Chrome extensions; the Extensions screen explains the limitation.
- **Ad blocking:** This build uses host-based blocking (seed domains plus an optional StevenBlack hosts list). It does not parse the full EasyList/Adblock Plus syntax, cosmetic CSS filters, scriptlets, or every service-worker request. Some ads may remain and some sites may need a site exception.
- **Private browsing:** A separate cookie-isolated private profile is not included. The app uses the regular Android WebView cookie store.
- **Safe Browsing:** WebView's built-in Safe Browsing behavior is enabled, but there is no separate ORBIT cloud reputation service.
- The debug APK is signed with the standard Android debug key. It is suitable for testing/sideloading, not Play Store publishing.

## Build using GitHub Actions (tablet-friendly)

This repository includes `.github/workflows/build-android.yml`.

1. Create a GitHub repository and upload the **contents** of this project to its root. Keep the `.github/workflows/build-android.yml` path intact.
2. Open the repository's **Actions** tab.
3. Select **ORBIT Android APK**.
4. Tap **Run workflow** and confirm.
5. Wait until the run finishes successfully.
6. Open the completed run and download the `ORBIT-Android-APK` artifact.
7. Extract the downloaded ZIP. It contains `app-debug.apk`.
8. Open the APK on the Android device and allow installation from that source when Android asks.

The APK is built by GitHub's hosted Linux runner. This source package itself is not an APK.

## Build locally (computer with Android SDK)

Requirements:
- JDK 17
- Android SDK Platform 35 and Build Tools 35.0.0
- Gradle 8.9

From the project root:

```bash
gradle --no-daemon assembleDebug
```

Output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Minimum supported Android version: Android 10 (API 29). Target SDK: 35.

## Project layout

```text
ORBIT-Browser-Android/
├── .github/workflows/build-android.yml
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/orbit/browser/
│       │   ├── MainActivity.java
│       │   └── BrowserDatabase.java
│       └── res/values/
├── build.gradle
├── settings.gradle
└── gradle.properties
```
